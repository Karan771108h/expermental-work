# Universal Master Template

A hyper-detailed, agent-first blueprint for taking any software idea (app / SaaS / extension / open-source tool) from raw concept to **production-ready with real users** — optimized for the Google ecosystem (Gemini Advanced, Google Antigravity, Agentic Workflows, MCP) and built on a **GitHub Leverage Map** of free, open-source foundations rather than reinvention.

**Version 4.0** — the full **7-pillar lifecycle** + an upfront Lean Stack (GitHub Leverage Map). Reworked after critical review (see the changelog in the doc's Iteration Log section).

## The master document
**`UNIVERSAL_MASTER_TEMPLATE.md`** — the full blueprint, one file. Contents:

- **§ A Lean Stack — GitHub Leverage Map** (NEW): the researched, compared, mixed set of open-source repos per workstream — validation templates, the **superpowers** agentic workflow engine (the repo you flagged), agent-skill marketplaces, UI systems, SaaS boilerplates, MCP tooling, CI/CD/monitoring, and launch/growth skills — plus the method to find more.
- **§ B** — the "find free resources" method (licensing, maintenance, security vetting).
- **Pillar 1 — Idea to Execution**: validating without writing code, human-behavior journey mapping, ruthless MVP scope, pre-dev checklist.
- **Pillar 2 — UI/UX & Design Taste**: curating free/open-source design systems, the non-negotiable UI laws, the Forbidden list, and an automated "taste" verification harness.
- **Pillar 3 — Code Architecture & Engineering**: universal modular structure, engineering laws, brain files.
- **Pillar 3b — Antigravity Optimization**: Implementation-Plan files, Skills, MCP hygiene, sandboxing/containment, autonomy trust ladder.
- **Pillar 3c — CI/CD & Deployment**: the full gated pipeline with agent guardrails.
- **Pillar 4 — Product-Type Awareness & Lean Stack Decision** (NEW): classify your product and weight every later pillar correctly.
- **Pillar 5 — Launch & Distribution** (NEW): getting found, launch sequence, free distribution stack.
- **Pillar 6 — Monetization & Pricing** (NEW): anchoring, models, Lean-Stack billing, pricing test loop.
- **Pillar 7 — Relentless Iteration Protocol**: the two loops, perpetual critique protocol, delegation runbook, post-launch measurement.
- **Appendices**: blank templates (IDEA_SHEET, JOURNEY_MAP, MVP_SCOPE, IMPLEMENTATION_PLAN), interview question bank, Iteration Log.

## How to use it
1. Read the doc top to bottom once — especially § A (the repo map) so you stop building from scratch.
2. Start an idea: copy Appendix A (IDEA_SHEET) and run Pillar 1 stages 1–2 — talk to humans before writing code.
3. When scoped: run Pillar 4 to classify product type, adopt the right Lean-Stack boilerplate + superpowers as your build engine, and delegate features per Pillar 3b.
4. Launch, price, and measure per Pillars 5–7; run the critique protocol (Pillar 7, Protocol A) forever.

*Verified facts about Antigravity and the repo ecosystem were grounded from current sources at build time; repos and tools evolve — the doc tells you how to re-verify before relying on any of them.*
