# UNIVERSAL MASTER TEMPLATE — Taking Any Software Idea to Production

**Version:** 4.0 — Full 7-pillar lifecycle + GitHub Leverage Map (rebuild driven by critical user review)
**Target user:** Solo founder / small team operating inside the Google ecosystem (Gemini Advanced, Google Antigravity, Agentic Workflows, MCP), with a Google Pro subscription and a hard appetite for free, open-source leverage.
**The one-sentence thesis:** You are not a code-writer in 2026; you are a *director of autonomous agents* on a *product manager's* mission. Your only irreplaceable jobs are (1) deciding *what truth to pursue* and *who actually suffers*, (2) defining *taste and constraints* the machine cannot infer, (3) picking the *best open-source foundations* instead of reinventing them, and (4) running a *relentless verification loop* all the way from idea to retained customers. Everything else is delegation.

> **Read me first — why this template changed and how it is structured.**
> In review you pushed two valid points: (a) the original stopped at "ship," but *production-ready* means real users finding, paying for (or adopting), and returning to a product — so this is now a **7-pillar full-lifecycle** blueprint; and (b) you were right that I under-used GitHub — so every pillar now sits on top of a **GitHub Leverage Map**: real, researched, battle-tested open-source repositories I compare and mix per workstream, rather than instructions I ask you to hand-roll. I lead with that map (below) because it is the single biggest shortcut the first version missed. Repos are living things — **always verify current stars, license, maintenance, and the install path in the repo's own README before relying on them** (the ecosystems here move monthly).

---

## § A — THE LEAN STACK: GitHub Leverage Map (the shortcut the v1 template missed)

Every idea → production step already has a **proven, free, open-source** foundation on GitHub. Do not build these by hand. This map is the master index; the pillars reference it. Strategy for choosing: read the "When to pick" + watch for **license / maintenance / stack-fit**, then prefer the option whose stack matches yours so you graft less.

### 1. Product discovery & validation (feeds Pillar 1)
| Repo / resource | What it gives you | When to pick |
|---|---|---|
| **jobsamuel/startup-mvp** (MIT) | Lean-Startup landing/template to test the "are people interested?" hypothesis | You want a deployable single page to start collecting signups/interest |
| **the MVP Experiment Canvas** (themvpcanvas.com, free) | Structured experiment canvas (hypothesis → metric → test) for designing cheap validation | You want a rigorous experiment *before* touching a template |
| **5DVision / BMC templates**, **Lean Canvas** | Value-proposition / business-model one-pagers | Free-form thinking and model clarity |
| **ipavelm/ultimate-product-discovery-skill** | An actual **agent skill** (Claude/Anthropic format): 18 tasks across Market Analysis, Customers (JTBD/CJM), Strategy (Lean Canvas), Validation, PMF, deliverables | You run agent skills and want the discovery *process* itself delegated |
| Interview / Mom Test | Not a repo — *The Mom Test* (Fitzpatrick) field guide | Non-negotiable reading before interviews |

### 2. Agent workflow / build methodology (feeds Pillar 3b & 4) — the one you flagged
| Repo | What it is | When to pick | Watch out |
|---|---|---|---|
| **obra/superpowers** (MIT, ~283k★) | The category-leading **agentic workflow framework**: 7-phase methodology (Brainstorm → Spec → Plan → TDD → Subagent Dev → Review → Finalize) packaged as ~14–20 skills (`brainstorming`, `writing-plans`, `executing-plans`, `test-driven-development`, `requesting/receiving-code-review`, `verification-before-completion`, `dispatching-parallel-agents`, `using-git-worktrees`, …). Ships `GEMINI.md`, `gemini-extension.json`, and an `antigravity-tools` reference. | You want a battle-tested **build loop** the community already hardened. **Use this as the execution engine** inside my Pillar 3b/4. | It covers the *build* phase only — it deliberately does **not** cover idea-validation or go-to-market. That's why I keep product/market pillars around it. |
| **anthropics/skills** (official; Apache-2.0 examples) | The **official Agent Skills catalog** + the spec that became an open standard (agentskills.io, adopted by ~40 clients incl. Gemini CLI). Broadest official instruction library + `skill-creator`. | You want the canonical, safest skill source and to author your own | Document skills (pdf/docx…) are source-available, not fully OSS — check |
| **skills.sh** (Vercel) + **awesome-claude-skills** / **awesome-agent-skills** | Skill **marketplaces / discovery indexes** (SKILL.md standard) | You want to browse/install community skills per task | **Security is a live crisis**: studies find prompt-injection in a large fraction of marketplace skills. Install only from trusted/maintained sources; audit what you add. |
| Alternatives worth comparing | **BMAD** (agile lifecycle), **github/spec-kit** (spec-driven greenfield), **ruflo** (formerly claude-flow), **agentsmd/agents.md**, **wshobson/agents**, **sickn33/antigravity-awesome-skills** (Antigravity-specific), **JasonColapietro/suede-creator-skills** (code+design+marketing+shipping) | Different enforcement weight (methodology vs. catalog vs. orchestration) | Superpowers is the default for solo/small teams; the others vary by philosophy |

### 3. UI/UX & design (feeds Pillar 2) — expanded beyond the design-system list
- **Design systems & primitives:** Radix Primitives, shadcn/ui, Mantine, DaisyUI, React Aria/Spectrum, Base Web, Ant Design, Chakra, MUI (see Pillar 2).
- **Curated indexes:** `awesome-design-systems` (alexpate), `awesome-design-tokens`, Open UI, Storybook.
- **Icons:** Lucide / Phosphor / Tabler / Heroicons / Iconify. **Illustration/motion:** unDraw, manypixels, Storyset, Lottie. **Type:** Fontsource. (Full shelf in Pillar 2.)

### 4. SaaS / app boilerplate — the biggest "don't build the skeleton" win (feeds Pillar 3)
The core auth + billing + db + emails skeleton is solved. **Pick one starter, don't assemble from scratch.**

| Repo / kit | Stack | Best for | License |
|---|---|---|---|
| **create-t3-app (t3)** | Next/TS/tRPC or REST, NextAuth, Prisma/Drizzle, Tailwind | Type-safe full-stack foundation (30k+★) | MIT |
| **nextjs/saas-starter** (Vercel, official) | Next.js, Postgres, Drizzle, Auth.js, Stripe, shadcn/ui | Clean, official **free** reference w/ basic teams | MIT |
| **ixartz/Next-js-Boilerplate** | Next 15, Drizzle, Auth.js or Clerk, Stripe, Tailwind | Free, **DevOps-ready** (ESLint+Prettier+Vitest+Playwright+Storybook+lint-staged) | MIT (+optional pro) |
| **wasp-lang/open-saas** | Wasp (React/Node/Prisma) | Free, opinionated, ships **AGENTS.md + Claude plugin** for AI-dev | MIT |
| **next-supabase-stripe-starter** (KolbySisk) | Next 15 + Supabase + Stripe + React Email/Resend + shadcn | Supabase-ecosystem product | MIT |
| **vercel/nextjs-subscription-payments** | Next + Stripe + Supabase | Clone-and-deploy subscription SaaS | MIT |
| **ChadNext** (moinulmoin) | Next + Supabase + shadcn + Umami | Lightweight rapid prototyping | MIT |
| *Paid reference* (not OSS): **ShipFast, MakerKit, supastarter** | — | Compare against free to see what you'd buy if you ever outgrow OSS | Commercial |

> **Grafting law:** never pick a boilerplate whose ORM/auth you'll fight. Match the starter's stack to your Pillar-1 decisions. Then the starter's own conventions *become* your AGENTS.md starting point — you override, don't rebuild.

### 5. Agent tooling / MCP (feeds Pillar 3b)
- **anthropics/skills** & marketplace indexes (see §2) for skills; **MCP server directories** (e.g., the official `modelcontextprotocol/servers` repo) for ready-made servers (filesystem, DB, git, fetch). Wire only what a task needs; keep active tools lean (Pillar 3b has the ~25-tool ceiling & tool-name gotchas).

### 6. CI/CD, hosting, monitoring (feeds Pillar 3c)
- **CI/CD:** GitHub Actions / GitLab CI / CircleCI (free tiers). **Starter-repo CI** often ships already wired.
- **Hosting:** Vercel / Netlify / Cloudflare Pages / Railway / Fly.io, or a VPS+Docker+Caddy. **Monitoring (free tier):** Sentry (errors — the MVP must-have), UptimeRobot/BetterStack (uptime), PostHog (product analytics + feature flags + session replay), Plausible/Umami (lightweight privacy analytics).

### 7. Launch & growth (feeds Pillar 5)
| Repo | What it gives you | Watch out |
|---|---|---|
| **coreyhaines31/marketingskills** (MIT, ~45–48k★) | The largest open-source **marketing/growth skills bundle**: SEO/AI-SEO, copywriting, CRO, pricing, launch-strategy, onboarding-CRO, email/lifecycle, referral, paid-ads, analytics, churn-prevention, paywalls, popups, programmatic-SEO + more. Installs as Claude Code plugin / skills folder / SkillKit. | Built for Agent-Skills-compatible agents (Claude/Cursor/Codex/**Gemini**); MIT so reuse freely. **Review each skill's prompt before use** — same skill-injection caution as §2. |
| **coreyhaines31/makerskills** | Skills for personal-operator/product tasks (complement to marketing) | Same install caveat |
| **aaron-he-zhu/aaron-marketing-skills**, **gooseworks-ai/goose-skills** (125+ growth/GTM skills) | Bigger/alternative marketing-skill stacks | Curate — don't install 100+ blindly |
| **inhouseseo/superseo-skills** | SEO/E-E-A-T/content audit skills | Niche SEO focus |
| **awesome-startup / launch lists** & Product Hunt community | Launch checklists & outreach | Curated by community |
| Free analytics/content tooling | PostHog, Plausible, Umami (see §6) | — |

> **Why these exist and you should lean on them:** a solo founder in 2026 does not need to *invent* a conversion-optimization methodology, a git-worktree workflow, or a SaaS skeleton — the open-source community already hardened them, and many now ship as **agent skills** your Gemini/Antigravity toolchain can invoke directly (SKILL.md became an open standard). Your job is **selection, licensing hygiene, security vetting, and integration** — not authoring. That is the whole point of the Lean Stack. For anything not covered here, find it the right way (see § B next).

## § B — The "find free resources" method (use it forever, per workstream)

When a workstream needs a foundation this map doesn't list, find it like a pro instead of guessing:
1. **Search GitHub topics/stars** (`github.com/topics/<topic>` sorted by stars) and awesome-lists (`awesome-<niche>`), because a high-star, actively-maintained repo is the cheapest trust signal.
2. **Check license** (MIT/Apache = freely reusable; GPL = viral copyleft; source-available ≠ open). Respect it — don't get burned (this is why every map row notes license).
3. **Check recency & issues**: recent commits + unarchived + responsive maintainers. A dead 40k★ repo can still be a trap.
4. **Prefer repo-native agent skills**: many ship `SKILL.md`/`AGENTS.md` now — that means your Gemini/Antigravity agents can use them directly.
5. **Cross-check security** before installing any skill/plugin (see the marketplaces warning in § A2).

---

## 0. Operating Doctrine (Read this first. It changes every pillar.)

Before any checklist, internalize five laws. Every rule in this document derives from them.

**Law 1 — Cost of validation is measured in hours, not dollars.**
Your scarcest asset is *iterations*, not money. A solo dev with a Google Pro sub should never burn a paid month on something a free tool settles in a weekend. Whenever a tool exists that collapses a task from "days of code" to "an hour of wiring," you take the wiring. This is why the whole template is built around curated free/open-source leverage instead of reinvention.

**Law 2 — The machine optimizes for "correct," you optimize for "true."**
An AI agent will happily build you a beautiful, correct feature *nobody wants*. Agents cannot suffer; they cannot lose sleep over your churn. Your job is to inject ground truth from real humans *before* and *between* every agent burst, then lock those findings into a written artifact the agent is forced to read. If you skip this, you are manufacturing elegant irrelevance.

**Law 3 — Taste is a constraint system, not a vibe.**
AI has no innate design taste, but taste can be *compiled* into checkable constraints: spacing scales, type ramps, contrast ratios, component provenance. You do not ask an agent to "make it look nice." You hand it a bound design system (Pillar 2) and a list of forbidden patterns. Taste, made explicit, becomes executable.

**Law 4 — Autonomy requires containment.**
The moment an agent can run commands, edit files, and call APIs, the question is no longer "can it?" but "what did we *let* it?" Unbounded autonomy produces unbounded surprises. Every task you delegate gets: a sandbox, a read-only contract of what it may touch, a written Definition of Done, and a verification artifact. Containment is what lets you run agents without babysitting them.

**Law 5 — The artifact is the interface between human and machine.**
Agents have short, lossy memory and read files far better than they hold chat context. So your project's *brain* is a set of living Markdown files: `PROJECT_BRIEF.md`, `CONSTRAINTS.md`, `AGENTS.md`, `MVP_SCOPE.md`, per-feature `IMPLEMENTATION_PLAN.md`. If it isn't written down, it doesn't exist for the agent. If it's written twice, it will drift — so there is exactly *one source of truth* for each fact, and everything else links to it.

---

## 1. The Google Toolchain Map (what you actually have, and where it bites)

You named four capabilities. Here is the honest job description of each, plus the traps.

| You said you have | What it really is | Its job in this pipeline | The trap |
|---|---|---|---|
| **Gemini Advanced / Gemini 3.x** | Frontier model(s) accessed via chat/API/CLI | Strategy synthesis, content drafting, review, the "relentless loop" critic | It will *agree* with you and *flatter* you. Treat every long response as a draft, never as truth. |
| **Google Antigravity** | Agent-first IDE + Agent Manager + CLI/SDK (built on a VS Code fork), powered by Gemini | **Execution engine.** Delegates whole features: plan → code → terminal → browser-verify. | One agent = one context. It loves to "just start." It will over-build scope and forget your constraints unless you feed it plan files (Pillar 3, Antigravity section). |
| **Agentic Workflows** | Orchestration / multi-step automation (Gemini API + Google Cloud) | Long, deterministic, repeated processes (CI checks, data pipelines, doc regen, MCP-managed QA). | Deterministic processes still drift when inputs change; put them under version control and let them produce artifacts you eyeball. |
| **MCP (Model Context Protocol)** | The *socket standard* that lets agents call your tools & data | Gives agents: your DB schema, your API docs, Git, your design tokens, testing harnesses — as typed tools. | Tool explosion. >~25 active tools degrades agent stability. Curate. (Cited practical ceiling.) |

**The single most important integration insight (use it everywhere):**
> Write your "brain" files in Markdown that agents read as ground truth, and expose your *executable* reality (schema, API, tests, tokens) through MCP servers. Markdown for *intent and constraints*; MCP for *live state and tooling*. Keep the two from duplicating each other.

**Antigravity-specific mechanics this whole template assumes** (grounded as of late-2025/2026, re-verify at `antigravity.google/docs` before relying):
- **Skills** = folders containing a `SKILL.md` (frontmatter `name` + `description`, then instructions, few-shot examples, optional bundled scripts). Workspace-scoped under `/.agent/skills/`; shared/global under `~/.gemini/skills/`. Skills make your standards reusable and teach the agent your house rules.
- **MCP servers** registered via `mcp_config.json` (project) or a shared global config. Antigravity enforces a strict tool-name regex (alphanumeric/underscore/hyphen) — if a server exposes names with dots, wrap it in a proxy that sanitizes names (documented real-world fix).
- **Manager view** spawns multiple agents across workspaces in parallel; each reports via **Artifacts** (task lists, implementation plans, screenshots, browser recordings) you comment on without stopping the run.
- **Policy gates** configure autonomy: agent-driven ("autopilot") vs. review-driven (asks before actions) vs. agent-assisted (recommended default). Plus terminal-approval and secure-mode toggles. **You will set: review-driven for destructive ops, agent-assisted for normal coding.**
- **Browser tool/subagent** = agents can load the running app and self-verify UI. This is your feedback loop for UI/UX tasks (Pillar 2) — make agents screenshot before/after against your checklists.
- **"Build with Google" bundles** ship pre-configured Skills + MCP servers for Firebase, Google Cloud (BigQuery, Data), Maps, Flutter/Dart, the Antigravity SDK. If you use those stacks, enable the bundle instead of hand-wiring.

> ⚠️ Antigravity is evolving fast (1.0→2.0 added CLI/SDK/managed agents/voice). Treat the *paths* below as live config; confirm folder locations and feature names in current docs before you build habits on them.

---

## 2. The Global Workflow (the spine every pillar plugs into)

This is the meta-process. You will loop it per-idea and per-feature. Stages A–G (the build spine) run primarily on Pillars 1–3 (idea → humans → scope → taste → scaffold → delegate → ship), then Stages G+ hand off to Pillar 4 (product-type weighting) and Pillars 5–7 (launch, monetization, retention/iteration).

```
[A] TRUTH  ── idea written down, honest wording, not code
    │  (Pillar 1 · stage 1)
    ▼
[B] HUMANS ── validate with real users, cheapest possible probes
    │  (Pillar 1 · stages 2–4)
    ▼
[C] SCOPE  ── ruthless MVP definition, feature triage by pain
    │  (Pillar 1 · stage 5)
    ▼
[D] TASTE  ── bind a design system + anti-pattern list, zero invention
    │  (Pillar 2)
    ▼
[E] SCAFFOLD ── repo, brain files, CI skeleton, standards config
    │  (Pillar 3)
    ▼
[F] DELEGATE ── Implementation Plans → Antigravity agents, sandboxed
    │  (Pillar 3b + superpowers engine + Pillar 7 Protocol B)
    ▼
[G] SHIP → MEASURE → LEARN → RETURN TO [A] with real data
    │  (Pillar 3c CI/CD → Pillar 4 type → Pillars 5-7 launch/monetize/iterate)
    └──────────────────────────────────────────┘
```

**The ruthless gate (never skip):** before [F] you must be able to answer "what does this feature do for which human, and how will we *see* it work?" If you can't, you haven't done [B] and [C] — go back. Cheap to check, expensive to ignore.

---

## 3. What "Done" Looks Like

This template is complete when your repo contains a **runbook** you could hand a stranger on day one of a paid role, plus the brain files and configs in Pillar 3, plus the blank templates in `/templates`. See the folder README for the file tree.

---
*(Continue to 02 — Pillar 1: Idea to Execution.)*
# PILLAR 1 — Idea to Execution (Human-Centric Strategy)

Goal: go from a raw idea to a *validated, scoped* MVP **without writing a single line of product code**, then define exactly what gets built.

---

## Stage 1 — Write the idea down with brutal honesty (30–60 min)

An idea in your head is a fantasy. An idea written down is a hypothesis. Force it through this template. Use `templates/IDEA_SHEET.md`.

1. **The Napkin Sentence.** One sentence: *For [who], who [frustration/pain], [product] is a [category] that [core outcome], unlike [alternative] because [differentiator].* If you can't fill a blank, you don't have an idea, you have a vibe. (This is the Lean Canvas / Heijl "one-sentence pitch" pattern.)
2. **The honesty audit.** Write out the idea's three weakest assumptions. Label each as either *fact you can check cheaply* or *belief you can't yet justify*. Most ideas fail here quietly.
3. **Kill criteria in advance.** Define 3 conditions under which you will *abandon* the idea (e.g., "no one in 20 interviews mentions the pain unprompted"). Deciding the exit *now* stops sunk-cost delusion later.
4. **Declare the moat or admit you have none.** If your only advantage is "I can build it," assume a clone appears in 90 days. What makes users stay? Distribution? Data? Network effects? If none, that's fine for a lifestyle tool — but *name it*, because it changes your MVP.

**The "don't build yet" rule:** none of this produces code. If you feel the itch to scaffold, you're procrastinating on the scary part (talking to humans). Sit on your hands.

---

## Stage 2 — Validate before building (cheapest probes first)

Order probes from cheapest-to-fake to most-expensive-to-fake. **Never write product code before probe 5.**

| Probe | Cost | What it really tests | Free/best tooling |
|---|---|---|---|
| 1. **Problem interviews** (15–20 target users) | ~3–5 hrs | Is the pain real, frequent, and felt? Do they *currently* hack around it? | Calendly free / Google Meet. You talk; you don't demo. |
| 2. **Pain-storm ranking** | 1 hr | Which pain is worth money/attention? | Google Sheets / Miro free. |
| 3. **Landing page + waitlist** | ~1 day | Does the promise convert strangers? | Vercel/Netlify + Tailwind or Carrd; waitlist = Google Sheets form or Tally free. |
| 4. **Fake door / concierge test** | ~2–5 days | Would they use it / pay if it existed? You manually fulfill "the product." | Same landing + a real calendar; you're the backend. |
| 5. **Clickable prototype** | ~1–2 days | Usability and flow sanity. | Figma (free) or a hand-wired static demo in Antigravity. |
| 6. **Prepaid/PILOT pilot** | weeks | Will anyone commit money or a written contract? | Stripe test / invoicing. The strongest signal is money or a signed MOU. |

**Rules that make interviews worth your time (this is where "how humans actually behave" lives):**
- **Never ask "would you use X?"** People say yes to be polite. Ask about the *past*: "Last time you hit [problem], walk me through exactly what you did." Past behavior is truth; stated intention is theater.
- **Listen for the workaround.** If users already hand-roll a spreadsheet/notion/hack to cope, that's your real competitor and your proof of pain.
- **Quantity beats polish.** 15 messy interviews > 3 polished ones. Patterns only appear around 8–10.
- **Ask "how often" and "what does it cost you."** Frequency and money convert "mildly annoying" into "fits in MVP."
- **The Mom-test version:** talk only about their life and past behavior, never pitch, never fish for compliments. (Book: *The Mom Test*, Rob Fitzpatrick — read the summary at minimum.)

**Red flags that mean STOP (do not pass Scope):**
- Every interviewee needs you to explain the idea twice → the problem isn't framed in their words.
- "That's cool, but I'd never pay for it" repeated → differentiator is a toy.
- You can't find 15 people who fit the profile → your target segment is imaginary or your positioning is wrong.
- Everyone already solved it with a free hack and is *happy* → no pain, no product.

---

## Stage 3 — User journeys from real behavior, not assumptions

AI (and first-time founders) model users as rational, linear actors. Real humans are irrational, impatient, and habitual. Map the *actual* path.

**Method — a "journey from field notes," not from a whiteboard:**
1. Take your 15+ interview transcripts and code every distinct *step* a person mentioned taking around the problem (from first awareness to resolution to repeat). Group near-duplicates.
2. For each step, record: **emotional state** (what they said/felt), **time spent**, **tools touched**, **drop-off likelihood**. You are looking for the *friction points*, not a pretty funnel.
3. Assemble into a **current-state journey** (what they do today, without you) — 5–8 steps max. Then overlay the **future-state journey** (what they'd do with your product) and mark exactly which steps you delete/compress. **Your product's value = the steps you remove.**
4. Only then draw the **happy path + 2 edge paths** (novice user, returning power user, and the "oops I made a mistake" path).

**Universal human-behavior truths to bake in (real psychology, not vibes):**
- **Present bias:** people value "now" far over "later." If your product's payoff is deferred (habit, finance, health), you must engineer a *near-term win* or they quit.
- **Loss aversion:** fear of losing > joy of gaining. "You'll lose your draft if you close" beats "save your work."
- **Cognitive load cap:** novices can hold ~3–4 new concepts comfortably. Onboarding that dumps 12 steps is dead on arrival.
- **Choice overload:** 3 options beats 7 (Hick's law). Defaults are the most powerful persuasion tool in your UI — set them to the *outcome users actually want*, never to *your revenue target*.
- **Status quo bias:** the default action is "do nothing." Your funnel must aggressively lower the cost of the *first* action, because inertia is your biggest competitor.
- **Reciprocity & social proof:** a visible "used by / testimonials / cohort activity" reduces perceived risk in the first 30 seconds.
- **Recency for retention:** whatever a user does last is what they remember. End every session on a *win* (a clear "done", a saved confirmation), not on a dead end.

**Artifact:** `templates/JOURNEY_MAP.md` → becomes a single markdown file with the current-state path, future-state path, and the friction list ranked. This file is *input* to MVP scope and to every agent UI task.

---

## Stage 4 — Competitor & market scan (the free shortcut pass)

Do not "research the market in the abstract." You need four concrete outputs. Free sources for each:

1. **Who already wins, and how they win** — search the category on Product Hunt (historical launches + comments reveal pains), G2/Capterra review complaints (sort by 1-star: people write their *true* pain there), Reddit/communities. **Output:** a 3-row table of competitors × (their core offer, their price, their most-criticized gap).
2. **The gap that is YOUR wedge** — from those 1-star reviews and interview notes, name the single unmet need. If it doesn't exist, do not proceed.
3. **Total addressable noise vs. real demand** — check search volume on the problem phrasing (Google Trends relative, keyword tools) and community *active* membership. Small-but-painful beats large-but-casual for a solo founder.
4. **Price floor anchors** — what do people already pay to solve this (competitor plans, or the cost of the current workaround in hours)? Your price lives just below that anchor.

**Anti-research rules (do not sink a week here):** no 40-page market reports, no fake "blue ocean" narratives, no modeling $100M markets. You need ~half a day of *targeted* extraction, because the market will not pay you for your report — it pays for the wedge.

---

## Stage 5 — Ruthless MVP scope (the triage you'll defend forever)

**Definition of MVP (say it out loud):** the *smallest* thing that delivers the *core painful outcome* to *early-adopter humans*, and produces *a measurable signal* that you're right. NOT the smallest thing you can ship. NOT a demo. If it doesn't produce signal, it's not an MVP, it's a prototype you dressed up.

**Feature triage — the two-question gate.** For every candidate feature, ask:
1. **Does it touch the #1 ranked pain** (from Stage 2/3), or is it adjacent/secondary? Only the top pain earns a place by default.
2. **Can users reach the core outcome WITHOUT it?** If yes, it's scope bloat for now. Defer it.

Then apply the **Pareto + regret test**:
- **Must (core loop):** directly necessary for the promised outcome. Smallest viable form.
- **Should (delight, still core):** materially lifts activation/retention of the *core* loop; include only if cheap.
- **Could (nice-to-have / bloat):** everything else → backlog, explicitly. Call these out by name so you feel the weight of cutting them.
- **Won't (this version):** write these down too. Naming what you refuse is what makes a scope *ruthless* rather than merely "small."

**Sharpening tricks (this is where scope really dies):**
- **The "90% of value" prune:** if a feature gives ~10% of value for ~40% of effort/risk, cut it to a stub or kill it.
- **The single-user / single-path MVP:** many tools can launch solving one persona on one path, then generalize. Resist the multi-tenant, multi-role siren.
- **"Boring core" test:** the core loop should feel almost *too plain* (one primary action, one result). If your MVP has an elaborate dashboard of charts, you likely built a reporting tool nobody asked for.
- **Manual-behind-the-scenes:** anything you can do by hand for the first 20 users (onboarding, "AI" features, integrations) is not an MVP requirement. Automate only when it hurts. (This frees enormous scope and gives you real usage data before you build.)
- **Auth/plans:** you need *enough* auth and *one* payment path to take money — no more. Login-by-magic-link or OAuth via Supabase/Firebase, one paid plan, done. Do not build roles, orgs, trials-gymnastics, or coupon engines at MVP.

**The outcome of this stage** is a file that is *the contract between you and every agent*: `MVP_SCOPE.md` containing Must/Should/Could/Won't, the core loop in one sentence, the primary user journey, and the **3 success signals** (activation metric, a usage signal, and a "people keep using it" signal) that you'll measure post-launch.

---

## Stage 6 — Pre-development checklist (the gate into Pillar 2/3)

Tick every box before any code. Each maps to an artifact already produced above — if an artifact is missing, go back.

**Market & user:**
- [ ] Napkin sentence (For/Who/That/Unlike) written.
- [ ] 15+ problem interviews completed and quotes filed.
- [ ] 3 kill-criteria defined in writing.
- [ ] Current-state journey mapped from transcripts (not assumptions).
- [ ] Future-state journey: the steps you delete, listed.
- [ ] Competitor gap table (3 × their most-criticized gap).
- [ ] Target persona named with a *verifiable* profile (where they congregate, how they'd be reached).
- [ ] Price anchored below the current workaround cost.

**Scope:**
- [ ] Core loop = one sentence.
- [ ] MVP_SCOPE.md with Must/Should/Could/Won't + 3 success signals.
- [ ] Every "Could/Won't" explicitly deferred to backlog (visible).
- [ ] Manual-behind-the-scenes decisions documented (what you'll hand-do first).

**Decision-maker honesty:**
- [ ] Moat declared (or "none," accepted as a choice).
- [ ] Abandon criteria present and agreed with yourself/partner.

> **Gate:** If any box is empty, you do not yet know what to build well, and agents will guess. Close the gaps in Pillar 1 before buying a single design token.

---
*(Continue to 03 — Pillar 2: UI/UX & Design Taste.)*
# PILLAR 2 — UI/UX & Design Taste (the Free Open-Source Ecosystem)

The law you must internalize: **AI cannot invent taste, but taste can be imported from the best open-source systems and then enforced as constraints.** You will almost never design a component from scratch. Your job is curation + constraint-binding + verification, not invention.

---

## The strategy in one paragraph

Never open a blank canvas. Pick **one** battle-tested open-source foundation (Radix/React Aria headless layer + a Tailwind-based layer like shadcn/ui, or a fully styled system like Mantine/DaisyUI for speed). Bind its *design tokens* (color, spacing, type, radius, shadow) as the single source of truth. Import the free component/icon/illustration libraries you actually need. Then hand the agent a *Constraints file* + *Forbidden list* + *screenshot self-check* so it can't drift into generic "AI look." This is how you get taste without being a designer.

**Decision shortcut — pick your lane by speed vs. control:**
- **Control + accessibility ceiling (recommended for real products):** Radix Primitives (or React Aria) headless primitives + Tailwind + shadcn/ui component layer. Best a11y, full styling control, moderate wiring.
- **Speed, opinionated (hackathon/MVP-in-weekends):** Mantine (batteries-included), or DaisyUI on Tailwind. Ship fast, slightly less bespoke.
- **Android / native:** Material Design 3 + Material Components.
- **Apple platforms:** SwiftUI + HIG (Human Interface Guidelines).

**Rule of thumb:** do not mix two full component systems (e.g., shadcn *and* Mantine together) — you'll fight token/spacing conflicts. One foundation + imports from token-agnostic asset libraries only.

---

## Curated free/open-source source list (verify links, then bookmark)

### A. Foundations & component systems (pick ONE primary)
- **Radix Primitives** — github.com/radix-ui/primitives — unstyled, accessible primitives (dialog, dropdown, toast, tabs…). A11y backbone.
- **shadcn/ui** — ui.shadcn.com — copy-paste components built on Radix + Tailwind + CSS vars. The current default for React; great token structure.
- **React Aria / React Spectrum** (Adobe) — react-spectrum.adobe.com — accessible React hooks/components; if you need serious a11y & data-viz integration.
- **Tailwind CSS** — tailwindcss.com — the utility engine + (v4) CSS-first config. Pairs with almost everything below.
- **Mantine** — mantine.dev — batteries-included React component library (hooks, forms, notifications, dates). Fastest path to a polished admin/app.
- **DaisyUI** — daisyui.com — pure-Tailwind class components, fastest ugly-free styling.
- **Ark UI / Zag** (Chakra team) — ark-ui.com — headless + styleable across frameworks.
- **Kobalte / Ariakit / Headless UI / Reach** — more headless alternatives; pick per need.
- **Base Web** (Uber) — github.com/uber/baseweb — full system if you want consistency out of the box.
- **Ant Design / Chakra / MUI** — larger ecosystems; great for data-dense admin (Ant) or simplicity (Chakra).
- **Enterprise design systems to *steal patterns from*** (their code on GitHub, style as reference): Carbon (IBM), Fluent (Microsoft), Primer (GitHub), Polaris (Shopify), Paste (Twilio), Pajamas (GitLab), HIG (Apple), Material (Google), Spectrum (Adobe).

### B. Curated indexes (the "don't search, browse a shelf" hack)
- **awesome-design-systems** — github.com/alexpate/awesome-design-systems — the canonical shelf of component systems & their storybooks. Bookmark it.
- **awesome-design-tokens** — github.com/sturobson/Awesome-Design-Tokens.
- **Open UI** — open-ui.org — community spec for web UI (reads like UX research); cite it when an agent argues about pattern behavior.
- **components.guide** / **ui-libraries lists** — cross-framework component comparisons.
- **Storybook** — storybook.js.org — free; run every design system's components in it. Your agent-verification harness for UI.

### C. Color, tokens & theming (never hand-pick hex codes)
- **Radix Colors** — radix-ui.com/colors — accessible, well-tuned palettes (including dark), purpose-built. First choice.
- **Open Color** — github.com/yeun/open-color.
- **Tailwind palette + the Tailwind UI color generator** for ramps.
- **Leonardo** (Adobe) — for contrast-safe token generation (WCAG).
- **Color spaces to avoid inventing:** never eyeball contrast — compute it (a11y tools below). Use 60-30-10 (dominant/neutral/accent) as your base ratio.
- **Light+Dark as first-class:** ship dark mode from day one (agents will thank you; it's expected now).

### D. Typography
- **Google Fonts** (fonts.google.com) + **Fontsource** (npm packages of the same fonts, self-hosted for privacy/perf). Self-host — don't hotlink Google.
- **Pick ≤2 families** (display + text) with wide weights; use **type scale systems** (modular scale ×1.25/1.2 or Tailwind's ramp). Never 20 font sizes.
- Prefer a highly-legible text font (e.g., Inter, System stack is honestly fine). For data, consider a tabular/mono for numbers.

### E. Icons (use ONE icon set consistently)
- **Lucide** (lucide.dev) — the default; consistent stroke, huge set, MIT. Or **Phosphor** (weight variants), **Tabler** (1700+), **Heroicons** (Tailwind's), **Iconoir**, **Google Material Symbols**. **Iconify** (iconify.design) as a unified search/API across all sets — but in *product*, vendor one set for consistency. Consistency > variety.

### F. Illustrations / imagery / motion (use sparingly; photos rarely needed)
- Illustrations: **unDraw, manypixels, Storyset, Blush, Lukasz Adam / Humaaans, Control** (mostly free w/ license check). Limit illustration use — over-illustrated UIs read as stock SaaS.
- Photos: **Unsplash, Pexels, Openverse (search all CC), Wikimedia Commons**.
- Motion/loading: **Lottie** + free LottieFiles libs; **CSS-only** for micro-interactions (no JS lib needed).
- Gradients/mesh/texture (sparingly): Hero Patterns, SVG pattern generators; noise via tiny base64 textures.

### G. Product copy & empty states (the most underrated free win)
- **Simple Icons / logos** where needed; **Good Copy** (goodcopyhq) & app UX copy banks for onboarding/empty-state wording; **Microcopy** references. Empty states are a UX feature — write them like a person, give next action.

---

## Non-negotiable laws of good human UI (the Constraints file content)

These become the rules you feed every UI agent. Each is checkable.

### Spacing
1. **8px/4px grid.** All spacing is a multiple of 4 (or 8 for larger gaps). No random values. Derive from design tokens (`space-1…space-N`), never hardcode px in components.
2. **Space in relationship to content density:** tight for dense tools, generous for marketing/landing. Consistency within a screen type is the real law.
3. **Grouping by whitespace > grouping by borders/lines.** Related items share proximity; borders are a fallback, not the default.

### Typography & legibility
4. **Type scale, not free sizes.** Use a defined ramp; body 15–16px; never below ~14px for primary text (accessibility + readability).
5. **Line-height ~1.4–1.6 for body**; max line length ~45–75ch for reading text.
6. **Min 2 typefaces max**; use weight + size for hierarchy, not color alone.
7. **Text contrast ≥ 4.5:1** body, ≥3:1 large/UI (WCAG AA). Compute, don't eyeball. (Tool: WebAIM Contrast Checker / axe.)

### Color & hierarchy
8. **One action per screen** (primary button). Use neutral-heavy surfaces; reserve saturated color for meaning + the single primary action. 60-30-10.
9. **Color never sole signal** — always pair with icon/text (colorblind users). Red errors, green success — but with icons/words too.
10. **Meaning is consistent:** destructive is red across the app; brand color is not used for destructive, and vice-versa.

### Interaction & feedback (micro-interactions)
11. **Every action yields feedback in <0.1s (instant) or <0.4s (progress).** Nothing silently hangs. Buttons depress, states change, errors appear near the offending field.
12. **Optimistic UI** where safe — respond before the network resolves, then reconcile. But on *money/destructive* actions, confirm or disable.
13. **Affordance honesty:** things that look clickable are clickable; links look like links; disable ≠ hide.
14. **Motion is ≤200–300ms and purposeful** (explains spatial change), respects `prefers-reduced-motion`.

### Cognition & flow
15. **3–4 new concepts max in onboarding.** One step, one ask. Progress visible. Never a 12-field wall on first run.
16. **Progressive disclosure:** advanced options behind "More", not dumped upfront.
17. **Defaults = the user's desired outcome** (present-bias). Empty states show a clear next action and a reason to start now.
18. **Consistency of placement:** nav, search, primary action in predictable spots across screens; standardize.

### Layout & states
19. **Handle every state explicitly:** loading, empty, error, partial, offline — each gets a designed state (agents forget these; your checklist catches them).
20. **Responsive + touch targets ≥44px.** Mobile-first thinking even if desktop-primary.

---

## The Forbidden List (anti-patterns that scream "default AI")

Feed this to agents verbatim. Ban:
1. Centered hero + "Empower / Seamless / Revolutionize" marketing-speak everywhere.
2. Purple-blue gradient on every button; glassmorphism as a default.
3. Cluttered dashboards full of charts nobody asked for.
4. Generic stock-photo people in hero sections with fake "smiling in office" energy.
5. Cookie-cutter multi-step onboarding that asks questions you don't use.
6. 8+ nav items; 5+ footer columns of links; mega-footers.
7. Content that requires horizontal scrolling; 100%-width unconstrained text blocks.
8. Arbitrary hex colors, misaligned spacing (see 8px grid), mixed border radius per component.
9. Confetti/marquee/carousel auto-advancing content; autoplay video with sound.
10. Confusing double-actions (primary + secondary that look equal); destructive placed next to primary without spacing.
11. Dark-only design with no light mode; pure-black (#000) backgrounds (use off-black tokens).
12. More than 2 typefaces, or system-font soup mixing within a screen.
13. Walls of text with no scannable hierarchy; no empty-state design.
14. Poor focus visibility / removing outlines "because they look bad" (kills keyboard users).
15. Labels that lie or jargon; Latin-lorem placeholder copy shipped.
16. Toast spam (multiple simultaneous toasts); every success gets a modal.
17. Inconsistent icon style/size; mixing Lucide + filled-set + emojis as icons.
18. Non-rounded or wildly-rounded radius inconsistently; shadows on everything.
19. Accessibility theater (aria attributes that don't work, keyboard traps, unlabeled controls).
20. Micro-interaction overkill that slows users (every card wobbles) or animates on load for 2s.

---

## Verification harness for UI (how you and Antigravity "check taste")

Taste is subjective; *conformance* isn't. Automate the checkable parts and eyeball the rest:
1. **Axe/axe-core** (free) in CI + browser — automated a11y (contrast, labels, landmarks). Non-negotiable gate.
2. **Lighthouse** (free) in CI — performance + a11y + best-practices scores as a floor (e.g., ≥90).
3. **Design-token lint:** a test that no magic color/spacing/radius values appear outside the token file (agent-proof your scale).
4. **Screenshot self-review protocol:** after every UI task, the agent (Antigravity browser) loads the page and screenshots it against your Constraints + Forbidden list, pasted into the task's Definition of Done. You review the *artifact screenshot*, not the code, for the aesthetic call.
5. **Responsive sweep:** screenshots at 375 / 768 / 1280 widths; interactive states (hover, focus, error) too.
6. **Empty-state sweep:** force the empty/error/loading states and screenshot them — they reveal whether states were actually built.

**Golden rule:** for the *irreducible aesthetic* choices you can't automate, borrow from the systems you already imported. If you're unsure whether a spacing/color/radius is right, the design system's default is *more right* than your improvisation. Defer to provenance.

---
*(Continue to 04 — Pillar 3: Code Architecture & Engineering Standards.)*
# PILLAR 3 — Code Architecture & Engineering Standards

Goal: a repo structure and set of engineering laws that (a) scale cleanly, (b) survive 10+ parallel agent edits without chaos, and (c) make every file's purpose discoverable by an agent in seconds. If a human can't tell where a file belongs, neither can an agent — and agents edit at 10× your speed, so ambiguity costs you 10×.

---

## Rule zero: the repository is a contract between you and every agent

Two axioms drive everything below:
1. **Names carry meaning.** File/folder names ARE the documentation. If a module is named `utils`, you've given agents nothing; name it by responsibility.
2. **One source of truth.** Every fact lives in exactly one place; anything that depends on it *references* it. No duplicated config, no copy-pasted components. Duplication is where autonomous agents diverge.

---

## Universal modular structure (framework-agnostic, illustrated with Next.js + TS)

The structure below works for monorepo-safe small apps and extends to microservices later. **Layering is the point:** `domain (pure) → data → application → presentation`, dependencies flow inward. Agents that respect this never leak DB into UI.

```
my-app/
├─ app/                          # (Next.js App Router) route/frame layer ONLY
│  ├─ (marketing)/               # landing, pricing — route groups
│  ├─ (app)/                     # authenticated product shell
│  │  ├─ dashboard/
│  │  ├─ settings/
│  │  └─ layout.tsx              # shared shell/nav
│  └─ api/                       # route handlers (thin, delegate to services)
│     └─ auth/ [...nextauth]/route.ts
├─ src/
│  ├─ domain/                    # PURE business logic + types. No I/O, no framework.
│  │  ├─ entities/               # entities + value objects
│  │  ├─ use-cases/              # application services / interactors
│  │  ├─ rules/                  # business rules, invariants
│  │  └─ types/                  # shared domain TS types
│  ├─ data/                      # I/O boundary
│  │  ├─ db/                     # schema/migrations/drizzle|prisma
│  │  ├─ repositories/           # data-access interfaces + impls
│  │  └─ external/               # API clients, webhooks, file storage
│  ├─ application/ (bridge)      # use-case orchestration, auth session, validation
│  ├─ presentation/ (if SPA/component-heavy)
│  ├─ server/                    # (Next) server-only: auth, middleware-ish, server actions
│  ├─ middleware/                # (Next) middleware.ts — path guard rails
│  ├─ components/
│  │  ├─ ui/                     # design-system primitives (shadcn/ui here)
│  │  ├─ feature/                # feature components, one folder per feature
│  │  └─ layout/                 # shells, nav, headers
│  ├─ features/ (or colocate)    # ONE folder per feature: component+logic+hooks
│  │  └─ {feature}/
│  │     ├─ index.ts             # public API (barrel)
│  │     ├─ components/
│  │     ├─ hooks/
│  │     ├─ state/
│  │     ├─ api.ts               # feature-specific client calls
│  │     └─ Feature.test.ts
│  ├─ hooks/                     # REUSED cross-feature hooks only
│  ├─ lib/                       # framework glue, config, providers (NOT dumping ground)
│  ├─ utils/                     # PURE helpers, no side effects (grouped by domain: date, format, math)
│  ├─ styles/                    # global css, design tokens, theme
│  └─ assets/                    # static images/fonts/icon-set
├─ public/
├─ config/                       # lint, tsconfig extends, codegen
│  ├─ eslint.config.mjs
│  ├─ jest.config.ts  ·  playwright.config.ts
│  └─ .env.example  →  .env.local (never commit real secrets)
├─ docs/
│  ├─ decisions/ADRs/            # architecture decision records
│  └─ brain/  (AGENTS.md, CONSTRAINTS.md, MVP_SCOPE.md, IMPLEMENTATION_PLANs)
├─ scripts/                      # ops: db seed, codegen, smoke, typecheck
├─ tests/
│  ├─ unit/  ├─ integration/  └─ e2e/
└─ (root) .gitignore · package.json · tsconfig.json · biome.json/eslint · .nvmrc
```

**Where things go — the decision table (agents will read this):**

| Item | Home | Never in |
|---|---|---|
| Business rules & entities | `domain/` | components, route handlers |
| DB schema & migrations | `data/db/` | anywhere else (single source) |
| API calls to *your* backend | `features/*/api.ts` | UI components directly |
| Calls to *third-party* APIs | `data/external/` | UI components |
| Reusable pure helpers | `utils/<domain>/` | a flat `utils.ts` (dump truck) |
| Reusable cross-feature hooks | `hooks/` | feature folders (kept only if truly shared) |
| Design primitives (buttons, inputs) | `components/ui/` | feature folders (share! don't fork) |
| Feature-specific bits | `features/<feature>/` | global `components/` |
| Server-only logic | `server/` or `domain/use-cases` | client components |
| Route definitions | `app/` | middleware |
| Middleware (path guards) | `middleware/` or Next `middleware.ts` | scattered route files |
| Images/fonts/static | `public/`, `src/assets/` | random deep folders |
| Config | `config/` + root dotfiles | hardcoded in code |

**Colocation rule:** a component, its test, its styles, and its local hooks live together under `features/<feature>/`. Global reuse is the *only* reason to promote something up to `components/ui`, `hooks/`, or `utils/`. Ask "who else needs this?" before promoting.

**Barrels discipline:** each `features/<feature>/index.ts` exports a clean public API. Agents import the barrel, not the internals — so you can refactor internals freely.

---

## Engineering laws (make these lintable & testable where possible)

1. **DRY with judgment.** Duplicate *once* is allowed (two callsites may diverge); at three, extract. But never abstract prematurely — YAGNI beats clever abstractions. Rule: extract when you can name the concept the code represents.
2. **Every exported function/component has a purpose and a type.** Use TypeScript strict mode, `noUncheckedIndexedAccess`, explicit return types on public APIs. Never `any` as a free pass — if you must, justify in an ADR and scope it tightly.
3. **Lint & format gate (CI-blocking).** Use **Biome** (fast, free, TS/JS) or ESLint+Prettier. *Format on commit*, lint in CI. No PR merges red. Keep config in `config/`.
4. **Naming is architecture.** Components = `PascalCase.tsx`, hooks = `useX.ts`, helpers = `camelCase`, constants = `SCREAMING_SNAKE`. Verbs for functions (`submitOrder`), nouns for types (`Order`), `is/has/can` for booleans. No `handleX` spam without intent.
5. **Fail loudly in dev, gracefully in prod.** Error boundaries at route + feature level (React `ErrorBoundary`). Expected errors (validation, auth) handled inline with user feedback; *unexpected* errors surface to a boundary + a monitoring capture. Never `catch {}` swallow. Provide a `UserFacingError` type to classify.
6. **State management: colocate, then lift.** 90% of state is local (component/`useState`) or server (fetched). Add a global store (Zustand, or Jotai/Redux Toolkit) only for genuinely shared client state. Server state → a data layer (TanStack Query / SWR); never mirror server data in a global store.
7. **API contract first.** For any endpoint: define the request/response types + status codes in one shared contract file (or OpenAPI). Zod (or a schema lib) validates at the boundary — client and server import the *same* schema, so a contract change is caught at compile time, not in prod. This is the single highest-value anti-drift move with agents.
8. **Database schema conventions:**
   - Every table: `id` (UUID/text or bigint), `created_at`, `updated_at`. Soft-delete via `deleted_at` only when auditable history matters — otherwise hard delete.
   - **Migrations only** for schema change (never raw DDL drift). Migrations are versioned files in `data/db/migrations`; CI runs `migrate` + verifies clean `down/up`.
   - Naming: `snake_case` tables/columns; singular conceptual entity names are fine but be *consistent*; foreign keys `{table_id}`.
   - **Always query via repository layer** — components never see SQL. Enables mocking and swapping DB later.
   - Row-level-safety: scope queries by owner/tenant at the repository, never trust the client.
9. **Security basics as law:** never log secrets/PII; `.env*` gitignored (commit `.env.example`); input validation at every boundary (see API contract); auth in middleware/server, never client-only; dependency audits (`npm audit` / Dependabot) in CI.
10. **Performance as convention, not afterthought:** no layout-thrash selectors, code-split route/feature chunks, avoid heavy libs in client bundles, use framework-native caching (Next `fetch` caching/`revalidate`). Lighthouse floor (Pillar 2) enforces.
11. **Testing pyramid with a floor:** unit tests for `domain`/`utils` (the logic you must not break), integration for repositories/API contracts, a *few* critical e2e paths (signup → core loop → pay). Convention: 100% coverage is a myth — cover what you'd be *embarrassed to break*. New feature = at least a test for its core rule + one e2e of the happy path.

---

## Configuration & dependency hygiene

- **Pin the toolchain:** `.nvmrc` (Node), lockfile committed (`package-lock`/`pnpm-lock`), explicit TS version. Reproducibility beats "latest."
- **Keep dependencies lean:** each dependency is a risk + a context cost for agents. Prefer the curated system in Pillar 2 over pulling five micro-libs. When adding one, delete one if you can.
- **Standardize generators:** use a CLI/scaffold script so every agent creates features/UI with the same shape (`scripts/new-feature.ts`). Agents produce consistent, reviewable structure instead of bespoke layout each time.

---

## The brain files (single source of truth, read by every agent)

| File | Purpose | Refreshed when |
|---|---|---|
| `docs/brain/AGENTS.md` | The map: structure, where things go, engineering laws, how to run/test. Antigravity/Skills read this first. | Any structural change |
| `docs/brain/CONSTRAINTS.md` | Non-negotiable: stack, design tokens, Forbidden list (Pillar 2), dependencies policy, must-keep invariants. | Any new rule |
| `docs/brain/MVP_SCOPE.md` | The scope contract + core loop + success signals (Pillar 1). | Scope change only |
| `docs/brain/JOURNEY_MAP.md` | Current/future journeys + friction list (Pillar 1). | New user research |
| `docs/decisions/*.md` (ADRs) | Why we chose X (postgres over mongo, Next over SPA). Prevents agents "fixing" a deliberate choice. | After each big decision |
| Per-feature `docs/brain/plans/IMPLEMENTATION_PLAN-<feature>.md` | The delegation contract (see Pillar 7, Protocol B). | Per feature |

**Provenance rule:** when a file says a rule, agents obey; when they want to change it, they must *edit the file* (a reviewable change), never silently ignore it. This is how you keep 10 parallel agents coherent.

---
*(Continue to 05 — Pillar 3 part 2: Antigravity Execution Optimization.)*
# PILLAR 3b — Antigravity Optimization (the Execution Engine)

This is the section that makes everything else *autonomous*. Antigravity will happily code all day — the failure mode is it coding the **wrong thing, at the wrong scope, unsafely, and untestably.** These rules fix that. Grounded in how Antigravity actually works: agent-first (plan→execute→validate), Agent Manager for parallel agents, Skills (`SKILL.md`), MCP (`mcp_config.json`), Artifacts (plans/screenshots/recordings) for review, and configurable policy gates.

---

## Principle A — Turn every feature into a written Implementation Plan the agent *reads*

Antigravity plans, but you must feed it a *contract*, or it will invent its own (broader, lazier, off-scope) plan. Give each agent a file that answers every question before it asks.

**The Implementation Plan template** (use `templates/IMPLEMENTATION_PLAN.md`) with these fields, in this order:

1. **Title + Goal (1 sentence, maps to MVP_SCOPE core loop).**
2. **Human context:** the exact user + pain from JOURNEY_MAP this serves. (Agents that understand *why* make better micro-decisions.)
3. **In scope / Out of scope** — copied from the MVP triage; name deferred items explicitly so the agent doesn't "helpfully" add them.
4. **Files to create / modify** — *explicit paths* only, referencing the AGENTS.md structure. Tells the agent exactly where to work → enables safe scoping.
5. **Tech contract:** stack bits it must use (schema lib, UI primitives, state tool, style tokens) — no new dependencies without approval.
6. **Data / API contract:** request/response types, DB tables/migrations needed.
7. **UX requirements** (paste the relevant Constraint + Forbidden rules from Pillar 2; empty/error/loading states explicitly).
8. **Definition of Done (DoD):** checkable. *e.g., lint passes, typecheck passes, unit test for the core rule, one e2e happy path, screenshots at 3 widths incl. empty/error states, Lighthouse ≥90, no new deps.*
9. **Verification steps the agent must run:** exact commands + what "pass" looks like. Make DoD executable, not aspirational.
10. **Sandbox/limits:** read-only files, no prod creds, which env it may touch, forbidden commands (e.g., no `git push`, no destructive DB ops without approval).
11. **Success signal** it should screenshot/report as an Artifact.

**Anti-patterns that cause agent drift (avoid verbatim):**
- "Build me a login" (no goal, no scope, no DoD).
- Plan files that describe 5 features at once (one feature = one agent = one plan).
- Plans that assume the agent remembers Pillar 1/2 context — *reference* the brain files instead (link, don't restate).
- DoD that says "make sure it works" (unverifiable). Everything must be a command + expected output or a screenshot.

---

## Principle B — Isolate tasks so an agent can be *safely autonomous*

Autonomy without containment is how you get an agent that migrates your DB or pushes to main. Structure for safe runs:

1. **One feature = one agent = one branch = one sandbox.** Create a branch per feature (`feat/<feature>`). The agent works there; nothing reaches `main` without your merge + CI green. This is your #1 safety rail.
2. **Write-protect shared/brain files.** In the agent's policy/task, mark `docs/brain/*`, migrations, config, and `package.json` as *read-only/approval-required*. Agents may not casually edit your source-of-truth files.
3. **Scope its tools by workspace & by MCP:** give the agent only the MCP servers the feature needs. Keep total active tools lean (practical ceiling ~25 for stability — document says tool explosion degrades performance). A feature task needs: Git, your DB schema/API contract MCP, lint/test — not the marketing-site, not the billing server, not a web scraper.
4. **Use policy gates appropriately:**
   - Normal coding → **agent-assisted** (you in control, agent automates safe steps).
   - Anything that runs commands / touches DB / network / deploys → **review-driven or terminal-approval**.
   - Full "autopilot" (agent-driven) only inside a *disposable preview sandbox* with no real credentials, for pure exploration.
5. **Sandbox by environment:** dev DB only, `.env.local` only, a **local or ephemeral preview** (not prod). Antigravity's built-in browser is your verification tool here — the agent can drive it in the sandbox without touching real user data.
6. **Establish a "recovery point" before each delegation:** commit a known-green state (or tag) so a bad agent burst is one `git checkout` away. Cheap insurance, enormous peace of mind.

**Agent manager mode (parallel):** when you have multiple independent features, spawn separate agents each on its own branch/workspace and review their Artifacts in the Manager view. Do NOT run two agents on the *same* files/branch — merge conflicts and contradictory edits follow. Serialize shared-file changes.

---

## Principle C — Make your standards a *Skill* (so the agent already knows the house rules)

Repackage your brain files as a **project Skill** under `/.agent/skills/` (Antigravity reads workspace skills here; re-check current path in docs). A `SKILL.md` with:

```
---
name: house-rules
description: Project structure, engineering laws, UI constraints and DoD format for this repo. Read before any coding task.
---
# House rules
1. Read docs/brain/AGENTS.md ... (structure & where files go)
2. Read docs/brain/CONSTRAINTS.md ... (tokens, forbidden list)
3. Never edit docs/brain/* without approval.
4. Run `pnpm lint` + `pnpm typecheck` + `pnpm test` before DoD.
5. Return a screenshot artifact for any UI change.
```

Because Skills load context automatically, every feature agent inherits your standards without you pasting them each time. **Few-shot rule:** include 1–2 worked examples in the Skill (Google's own guidance: examples materially improve accuracy). Keep Skills small and focused; too many/too long Skills cause context bloat and "instruction fatigue."

---

## Principle D — MCP as the agent's sense organs

MCP servers give the agent *typed, current truth* instead of stale guesses:

- **DB schema & introspection** (e.g., a Postgres/Neon MCP server) so the agent queries the *real* schema instead of assuming. Wire it read-only in dev.
- **Your API contract** as an MCP resource (OpenAPI/typed routes) so frontend agents call real endpoints.
- **Git** operations exposed via MCP or the IDE so status/flow is tool-driven.
- **Testing/QA harnesses** as MCP tools the agent can invoke (lint, typecheck, a runner).
- **Google "Build with Google" bundles** if you're on Firebase/Cloud — pre-configured Skills+MCP for those stacks. Enable rather than hand-roll.
- **Design tokens** as an MCP resource too, so any UI agent reads your actual scale instead of inventing colors.

**MCP hygiene rules:**
- Curate to ~15–25 active tools per agent context (practical stability ceiling — cite the ~25 guidance; keep well under it).
- Tool-name gotcha: Antigravity's MCP client enforces names matching `[A-Za-z0-9_-]`; servers exposing dotted names (some Google/Workspace tools like `docs.create`) fail to load — wrap them in a proxy that sanitizes names. Documented real fix; keep a `scripts/mcp-proxy.js` for it.
- Keep MCP config in `mcp_config.json` at project root (and shared config globally). Version the file so every agent starts consistent.

---

## Principle E — Autonomous diagnostics & sandboxed testing loops

Make the agent *prove* work, then re-prove after each change (the relentless loop in miniature):

1. **Red→Green contract:** give the agent a failing test first (you or it writes the test from the DoD), then it implements until green. Tests are the agent's self-correcting harness — the reason you can trust autonomy.
2. **Mandatory self-verification:** before DoD, the agent must run the verification list in the plan (typecheck, lint, tests) and paste/report outputs. If any red, it fixes and reruns (bounded to N attempts before it must ask you).
3. **Browser verification for UI:** agent loads the sandboxed app, screenshots happy/empty/error/responsive states, checks them against Constraints + Forbidden list, and reports Artifacts. You eyeball *artifacts*, not diffs, for taste.
4. **Static + dep audit** in the loop (its own lint + `npm audit`) so it doesn't ship a known CVE or broken rule.
5. **Escape hatches:** if the agent exceeds N fix attempts, hits an approval gate, or wants to add a dependency / touch a protected file, it must *stop and ask* rather than improvise. Configure a review policy so this escalates to you.

**The autonomy trust ladder** (raise only as the agent proves reliable):
1. Review-driven (asks before every write) → verify structure quality.
2. Agent-assisted coding only, sandboxed, one feature/branch → verify Artifacts.
3. Add browser self-verification + test-first → verify DoD adherence.
4. Only after several clean features: allow terminal/network within dev sandbox, still no prod, still one-feature-one-agent.

Do not jump to step 4 for a codebase whose conventions aren't encoded (AGENTS.md + Skill) and tested. Encoded standards are what make high autonomy *safe*.

---
*(Continue to 06 — Pillar 3 part 3: CI/CD & Deployment.)*
# PILLAR 3c — CI/CD & Deployment Pipeline

Goal: an automated pipeline where **your only manual steps are reviewing Artifacts, merging to `main`, and pushing a tag.** Everything between a merged feature and "in production" should be robots. The pipeline is also your *safety net* for autonomous agents — it catches what a reviewing human might miss.

---

## The ideal pipeline (GitHub Actions + a free host; adapt to your stack)

Every step below is a checkable gate. A red gate stops the line — no "we'll fix it after merge."

```
[feature branch]  ← agent works here, per feature
      │  (push)
      ▼
PR / branch CI        # 1. static & correctness
├─ typecheck
├─ lint + format check
├─ unit + integration tests (fast suite)
├─ dependency audit (npm audit / OSV)   # known-CVE gate
├─ design-token lint (no magic values)   # Pillar 2 guard
└─ coverage gate on domain/ use-cases only (not vanity 100%)

merge → main
      │
      ▼
Deploy preview (ephemeral, per PR/branch)   # 2. live verification
├─ agent browser screenshot sweep vs Constraints/Forbidden (or you eyeball)
├─ axe a11y run (CI, gate)
├─ Lighthouse ≥ 90  (gate; budget via config)
└─ e2e happy-path suite against the preview

merge to main → production build  # 3. ship
├─ migrate DB (versioned migrations, auto with backup; never raw DDL)
├─ build + export/static or container
├─ smoke test (healthcheck + 1 core request)
└─ deploy (Vercel / Netlify / Cloudflare / Fly / Railway / a VPS + Docker)

post-deploy                    # 4. verify it's alive
├─ uptime/health monitoring  (free: UptimeRobot, BetterStack free)
├─ error monitoring          (Sentry free tier — the MVP must-have)
├─ synthetic core-loop check (occasional real browser test of the happy path)
└─ logs centralized          (if self-hosted: a log service or structured logs)
```

**Free CI/CD hosts (pick one):** GitHub Actions (free for public, generous private quota) is the default. Alternatives: **GitLab CI** (free), **CircleCI**, **Buildkite**. Host the app on **Vercel / Netlify / Cloudflare Pages / Railway / Fly.io**, or **any VPS + Docker + Caddy/Nginx** if you want zero PaaS lock-in. You rarely need more than the free tiers at MVP scale.

**Environment management (avoid the classic footgun):**
- `preview` (ephemeral, per-PR) · `staging` (mirrors prod, your soak/QA) · `production`. 
- Secrets live in the CI/host secret store, **never** in the repo. Commit only `.env.example`.
- Migrations run *before* deploy in an explicit, reversible step with a fresh DB backup taken first. Rollback = redeploy previous image + `migrate down` if your tooling supports it (or design migrations to be backward-compatible so forward-only is safe — preferred).

**Deployment strategy decisions to make once and write in an ADR:**
- **Frequency:** deploy `main` continuously (small, frequent > rare, huge) — each deploy is small and easy to bisect.
- **Zero-downtime:** blue/green or rolling via the host. Never a `kill + restart` deploy for a live product.
- **Feature flags** (free libs: **PostHog**, **Flagsmith**, or in-app env-based flags) let you ship dark and flip on — invaluable when an autonomous agent ships a big change you want to expose gradually. Keep flagging dead-simple at MVP; don't build a flag platform.
- **Rollback drill:** define + *rehearse* the 5-minute rollback (redeploy last good tag). Knowing you can roll back is what lets you ship confidently.

**Guardrails specific to agent-produced code in CI:**
- **Hard fail on any dep change without review:** lockfile diffs flagged; no silent `pnpm add` on the way to green.
- **Schema drift detector:** CI compares migrations to a golden copy; any edit to an applied migration fails the build.
- **DoD test:** map each Implementation Plan's DoD items to CI checks so an agent "satisfying the DoD" and CI passing are the *same thing*.

---

# PILLAR 3 quick reference — the standards cheat sheet

**Structure** → layered `domain → data → application → presentation`; features colocated under `features/<feature>`; shared UI in `components/ui`; pure helpers in `utils/<domain>`; brain files in `docs/brain`.
**Engineering laws** → TS strict, lint+format CI gate (Biome/ESLint+Prettier), naming-is-architecture, error boundaries + `UserFacingError`, colocate-then-lift state, shared Zod schema as API contract, migrations-only DB, repository layer queries, secrets-in-store-only, security-as-law, Lighthouse floor.
**Antigravity** → every feature = written Implementation Plan (goal/scope/files/DoD/sandbox); one feature-one agent-one branch-sandbox; protect brain files; lean MCP (~15–25 tools) + name-safe servers; Standards as a `SKILL.md`; red→green test-first; screenshot/axe/Lighthouse self-verification; trust ladder before raising autonomy.
**CI/CD** → branch CI gates → preview w/ UI sweep → auto deploy `main` (migrations-first, backup, zero-downtime) → Sentry + uptime + synthetic core check. Rollback rehearsed.

---
*(Continue to Pillar 4 — Product-type awareness & the Lean Stack decision.)*

# PILLAR 4 — Product-Type Awareness & the Lean Stack Decision

The template's single most important "more pillars?" answer: **one rigid pillar-set for every product is wrong.** A paid B2B tool and a free consumer app share nothing past the build phase — so before anything else, you classify the product and let that flip how much weight each remaining pillar carries. This pillar is the switchboard.

## Step 1 — Classify your product (the type matrix)

Answer the two axes honestly from your Pillar-1 research (who really pays, and who really uses). This decides the weighting below.

| | **B2B / business buyer** | **B2C / consumer** | **Prosumer / developer tool** | **Internal / niche tool** |
|---|---|---|---|---|
| Who pays vs. who uses | Buyer ≠ user (champion problem) | Same person (impulse + emotion) | Same person (taste + workflow) | Company/team (adoption problem) |
| Monetization (Pillar 6) | **Heavy** — seats/plans/trials | Light — IAP/sub or ads | Medium — per-seat/free-tier | Usually none/allocated |
| Distribution (Pillar 5) | Sales + SEO + cold outbound, ICP | Growth loops, ASO/SEO, virality | DevRel, docs, Product Hunt, OSS | Internal rollout |
| Retention lever (Pillar 7) | Value-onboarding + admin value | Habit + notifications | Time-to-first-win + API | Workflow embedding |
| Typical free path | Freemium/trial | Free core, monetize power | Free + paid pro | Free |

**Not a 4-box answer?** Fine — real products hybridize. The rule is: **assign a primary type and drive its weighting.** If you refuse to pick, you get a generic template again — the exact failure we're eliminating.

## Step 2 — The product-type weight table (run before Pillars 5–7)

For each column, spend effort in proportion, not equally. "—" means near-zero now.

| Concern | B2B | B2C consumer | Dev tool | Internal tool |
|---|---|---|---|---|
| Go-to-market planning | High | Medium | High (devrel) | Medium |
| Monetization depth | High | Low–Med | Medium | — |
| Onboarding & activation | Very high | High | High | Medium |
| Retention/habit loops | High | Very high | High | Medium |
| Acquisition via SEO/content | High | Medium | High | Low |
| Product analytics/experimentation | High | High | High | Medium |
| Privacy/compliance | High (contracts) | High (regs) | Medium | High (internal) |

**Output of this pillar:** a one-line **Product-Type Declaration** recorded in `MVP_SCOPE.md` or the brain file (`templates/PRODUCT_TYPE.md`), e.g., *"B2B subscription tool for [role], single-tenant-friendly, sales-assist acquisition."* Every later plan and agent delegation now reads this line to know which pillar to weight.

## Step 3 — Choose the Lean Stack foundation (graft, don't assemble)

Now that the type + stack is declared, pick from **§ A Lean Stack**:
1. **UI/UX system** (Pillar 2): control-focused (Radix+shadcn) vs. speed (Mantine/DaisyUI).
2. **SaaS boilerplate** (Pillar 3): match to stack — t3 (type-safe TS), `nextjs/saas-starter` (free official), `ixartz` (devops-ready), `wasp-lang/open-saas` (agent-friendly), `next-supabase-stripe-starter` (Supabase ecosystem). *Grafting law:* match the starter's ORM/auth to your decisions; don't fight it.
3. **Agent workflow** (Pillar 3b): adopt **superpowers** as the build engine (it is the hardened default).
4. **Marketing/launch** (Pillar 5): `coreyhaines31/marketingskills` for the growth/launch discipline as agent skills.

**Then and only then** do the remaining pillars deploy — they assume these foundations exist. Each pillar tells you *which* repos and *which* of their skills to invoke for that stage.

---

# PILLAR 5 — Launch & Distribution (getting found)

You built it; now the failure mode is silence. Distribution is not an afterthought bolted on at the end — for a solo founder it is frequently **the differentiator**, and its strategy is set *before* you finish building (a launch needs assets, positioning, and channels you can't create in a day).

## The truth about distribution (internalize before the checklist)
- **Build does not equal demand.** The market will not find you. "If you build it they will come" is a myth for products with no existing channel.
- **Choose ONE primary channel + 1–2 secondary.** Trying everything means doing nothing well. Channel depends on your Pillar-4 type (B2B → outbound+SEO+communities; B2C → content+growth loops+stores; dev tool → docs+Product Hunt+DevRel/OSS).
- **Distribution is a *system*, not an event.** A one-off "launch week" gives a spike that decays. Plan the sustainable loop: create → distribute → capture → convert → retain → ask for more.

## Launch checklist (Product Hunt is optional; sequence is not)

1. **Pre-launch (build a runway 2–4 weeks before you're done):**
   - [ ] Claim **your name + domain + social handles** now (squatters don't wait).
   - [ ] Landing page live (from Pillar-1 stage 2) with a clear value prop + **email capture** (free: PostHog/Tally/Buttondown) + an easy share.
   - [ ] **Positioning one-liner** + the "For/Who/Unlike" sentence (Pillar 1) + 3 proof points.
   - [ ] Seed a **community** in the channel your ICP already lives (Reddit sub, Discord, LinkedIn, X, niche forums, dev platforms). Post genuinely, not spam. **Warm 10–20 real relationships** who can become first users and voices.
   - [ ] Compose launch assets with agents: product **copy** (coreyhaines `copywriting`, `launch-strategy` skills), **screenshots/recording** (Antigravity browser artifacts), a short **demo video**, and **docs/help** if it's a dev tool.

2. **Launch mechanics:**
   - [ ] Pick your primary venue by type (B2B: LinkedIn + outbound + SEO; B2C: app-store + social + growth loops; dev: **Product Hunt**, Hacker News, /r/..., OSS communities; niche: the exact community where your Pillar-1 ICP was found).
   - [ ] Time it to *when your audience is online*, coordinate supporters, and make sharing trivial (one link, short memorable message).
   - [ ] **Distribution engine per type** from `coreyhaines31/marketingskills`: SEO/AI-SEO + programmatic-SEO (long tail), content, cold email/outbound (B2B), referral/growth-loop copy (B2C), launch pages (all). Invoke the skills; don't hand-roll.

3. **Post-launch (turn the spike into a system):**
   - [ ] Capture every visitor → email (single most valuable asset you own).
   - [ ] Set up **analytics** from day one (PostHog/Plausible/Umami) so you can *see* the funnel.
   - [ ] **First-user response is a product** — answer every question publicly & fast; it's free support + social proof.
   - [ ] Keep the content/SEO engine running (the compounding channel); schedule consistency over intensity.
   - [ ] **Ask for referrals** at the moment of delight, and make it one click.

**Free distribution stack:** Product Hunt & Hacker News & Reddit & communities (free) · SEO/content/AEO via `marketing-psychology`/`ai-seo`/`programmatic-seo` skills · email capture via Buttondown/Tally/PostHog · analytics via PostHog/Plausible/Umami · social via Buffer free tier or manual with agent drafts. Paid channels are optional later, once you have signal that organic converts.

**Anti-patterns:** launching to an empty audience (no warm list/community) · "set and forget" a launch · posting everywhere at once thinly instead of one channel deeply · building distribution after the product is "finished" (too late to gather assets) · ignoring the ICP's actual hangout (pitching devs on LinkedIn, or CTOs on TikTok).

---

# PILLAR 6 — Monetization & Pricing (paying is a feature, not an afterthought)

Only if your Pillar-4 type monetizes — B2B/consumer/dev monetize; a free open-source or internal tool treats this as "—" and skips to Pillar 7. When you *do* charge, remember: **pricing is a product decision with UX consequences**, and it's set from research, then tested — never "picked" at the last minute.

## Step 1 — Price from anchors, not guesses
- Anchor to what people **already pay** to solve this (Pillar-1 stage 4) and to the **cost of the current workaround** in time/money.
- Price on **value delivered / outcome**, not cost-plus or "what feels fair."
- If you don't know what to charge, start with the price you're *almost embarrassed* to name (underpricing is the beginner's real, common error — the cost of a wrong-low price is locking in value perception, not "being nice"). Use `coreyhaines31/marketingskills` **`pricing-strategy`** skill to structure this.

## Step 2 — Choose a model that matches your type
| Model | Best for | Notes |
|---|---|---|
| Free + premium (freemium) | Consumer, prosumer, dev tools | Free tier is your acquisition + retention engine; gate the power features |
| Subscription (seats/plans) | B2B, ongoing-value SaaS | Pricing by value + usage; annual discount for cash & retention |
| Usage / metered | APIs, infra, dev | Aligns cost with value; needs clear pricing page + alerts |
| One-time/perpetual | Tools, plugins, extensions | Careful: no recurring revenue, support burden grows |
| Open-core / paid-hosted | Dev/infra OSS | Free core builds adoption; paid managed/hosted is the business |

**Bundle, don't nickel:** 2–4 clearly-differentiated tiers beat a maze of add-ons. Make the *middle* the obvious default (the decoy effect is a real human-behavior lever — see Pillar-1 psychology).

## Step 3 — Build billing as a bolt-on from the Lean Stack, never from scratch
- **Starter kits ship Stripe/Lemon-Squeezy/Polar wired** (see § A4: `nextjs/saas-starter`, `vercel/nextjs-subscription-payments`, `wasp-lang/open-saas`, `next-supabase-stripe-starter`). Use their webhooks, customer portal, and fixtures.
- **Keep MVP billing minimal** (Pillar-1 scope law): auth (magic-link/OAuth), one path to pay, customer portal, a cancel flow, and receipt emails. **No** coupon engines, trials gymnastics, or org-billing at MVP.
- **Handle the edge that *is* core:** failed payments + a save-offer cancel flow (use `churn-prevention` skill) — money is where reliability must not be bolted on late.

## Step 4 — The pricing test loop (relentless, cheap)
1. **Ship at a price, instrument, talk to users** about what they'd pay (past/spent-behavior again, not "is this fair?").
2. Raise/lower in **small, clean steps**; change ONE variable at a time; watch conversion + churn + upgrade-rate, not just revenue.
3. Watch **which plan people pick** — if everyone picks the cheapest, your tiers or value-perception are off.
4. **Never discount as the default** — it trains users to wait. Discount only for annual, pilot, or as a time-boxed launch offer with a clear end.

**Anti-patterns:** price = guess at launch · free forever tier that never converts · hidden cost surprise (transactional fees, seat math) · complex tier matrix · treating revenue as separate from product UX.

---

# PILLAR 7 — The Relentless Iteration Protocol (Runbook)

This is the operational heart — how you *actually run* the loop on any idea or feature, using agents as your acceleration, and how you apply brutal self-critique to your own product decisions. (Your instruction to me — "draft, find 20 faults, fix, repeat" — is applied to *this very document*; see the Iteration Log. But that discipline is not a one-time act: it is a *permanent protocol* you now run on everything.)

---

## The two loops (don't confuse them)

**Outer loop — Product truth (weeks):** idea → humans → scope → ship → measure → learn → refine/abandon. Runs continuously for the life of the product. If you stop looping outward, you stop listening to reality and start polishing your assumptions.

**Inner loop — Build quality (per feature/task):** within one delegation, run the critique-fix loop until the Definition of Done is met and red-flagged risks are retired. This is the loop you apply to *every* agent handoff and *every* decision.

The ruthless gate between them: **an outer-loop question ("does anyone want this?") can never be answered by an inner-loop action ("let's add a feature to make it better").** When you feel the urge to code your way out of a product doubt, that's the signal you're in the wrong loop. Stop. Do an outer-loop probe (a real user conversation or a landing-page test) instead.

---

## Protocol A — The perpetual critique protocol (yours & the agents')

For any significant artifact (a plan, a design, a piece of logic, a marketing page), run this. Do **not** let the machine stop at "looks good."

**A1. Draft** — produce the version that satisfies the brief.
**A2. Play the adversary.** Find faults on purpose. Force yourself into distinct, uncomfortable roles, one at a time:
- *The customer who doesn't care* — why would they abandon in 10 seconds?
- *The edge-case hunter* — what input, user, state, or device breaks this?
- *The competitor's CEO* — what's the cheapest way to copy and beat this?
- *The security reviewer* — where does this trust the client, leak data, or fail closed/open?
- *The new engineer* — could a stranger who read only the files understand and extend this without asking me?
- *The accessibility user* — keyboard-only, screen-reader, low-vision, `prefers-reduced-motion`?
- *The lazy agent* — what did the AI produce that's "correct but generic," or that merely satisfied the letter of the brief while ignoring the intent?
List concrete faults, not vague worries. Demand at least a fixed number (the classic bar: 20) — the number is there to stop you quitting early. The first handful are shallow (typos, small gaps); the real faults hide at #15+.
**A3. Fix everything you listed.** Re-draft. Treat an unfixed item as unfinished.
**A4. Re-review for a *new* set.** If you're re-listing the same faults, you're not digging; find different ones — deeper, cross-cutting, strategic.
**A5. Stop by an explicit rule, not laziness.** You stop when: (a) a full adversary pass yields only cosmetic nits; AND (b) every "could break" has a mitigation or an accepted, documented risk; AND (c) the remaining uncertainty is *empirically testable*, not a guess — and you've queued that test. That's "good enough to hand to reality," not "perfect." Perfection is not achievable in a doc; the protocol converges to *well-scrutinized*, and then the market gives the final verdict.

**You can drive this loop faster with agents:** have Gemini/Antigravity generate the adversary review (ask it to be genuinely harsh — "find the weakest assumption, assume the customer does not care"), then *you* arbitrate which of its faults are real and fix them. The machine is a tireless devil's advocate; you are the judge of what's actually true.

---

## Protocol B — The delegation runbook (per feature, step by step)

This is the concrete "how" that ties Pillars 1–3 into an autonomous build. Print/keep it beside the Manager view.

1. **Confirm the feature is in MVP_SCOPE (Must/Should) and has a Journey Map home.** If it's not a Must/Should, it doesn't get an agent today. (Gate from Pillar 1.)
2. **Write the Implementation Plan** from `templates/IMPLEMENTATION_PLAN.md`: goal tied to core loop, human context, in/out of scope, explicit file paths, tech/API/UX contract, checkable DoD, sandbox limits, success signal. One feature per plan.
3. **Stage the environment:** create `feat/<feature>` branch from a known-green commit; confirm brain files are write-protected in the task policy; wire only the needed MCP servers (lean toolset).
4. **Load the house-rules Skill** (or paste AGENTS.md + CONSTRAINTS.md references) so the agent inherits standards.
5. **Delegate in Agent Manager** (agent-assisted default; review-driven/terminal-approval for anything destructive). Task = point it at the plan + Skill, tell it its sandbox limits and its escape hatch ("if you hit a protected file, new dependency, or Nth failed fix, stop and ask").
6. **Watch the Artifacts, not the code.** When it returns a plan/screenshot/recording, review that. Comment inline on the Artifact to steer without stopping (Antigravity supports artifact feedback mid-run).
7. **Run Protocol A against its output yourself** (adversary pass + fix/accept), then push its branch through the CI/preview pipeline (Pillar 3c). Do not hand-merge a red build.
8. **Merge when green** (single-feature branch → main), which triggers the deployment pipeline (migrations-first, preview sweep, smoke test).
9. **Record the outcome + the signal** (did it move the success metric in MVP_SCOPE?). Feed that into the outer loop.
10. **Promote only proven patterns.** If the agent repeated a mistake, encode it: add to the Forbidden list, the Skill, or a lint rule so it never recurs. This is how your standards compound instead of stagnate.

**Post-mortem when a delegation goes wrong (rare, but prepare):** the three classic causes are (1) *ambiguous plan* (not enough in/out-of-scope or DoD), (2) *insufficient house rules* (agent didn't know a constraint), (3) *wrong autonomy level* (gave autopilot before standards were encoded). All three are fixable *in the files*, permanently. Never treat a botched run as "the AI is bad" — treat it as a standards gap and close it. That reframe is what makes agents reliable at scale.

---

## Protocol C — Post-launch measurement & iteration (close the outer loop)

You shipped. Now the "measure → learn" half, or the loop isn't closed.

1. **Instrument the 3 success signals** you locked in MVP_SCOPE (activation, a usage signal, retention). Keep it to ~5 metrics max — dashboard bloat is the anti-pattern. Use free **PostHog** (product analytics, feature flags, session replay on free tier) or **Plausible/Umami** (privacy-light) for events; keep the list tiny.
2. **Watch behavior, not just numbers.** Session recordings + the funnel drop-off reveal *where* humans actually stumble (this is your human-behavior map come alive). PostHog free tier includes replay.
3. **Talk to users again, now about usage:** "walk me through the last time you used it" (same past-behavior rule as Pillar 1 interviews). Collect 5–10 quick calls / a feedback form.
4. **Triage feedback the MVP way** (two-question gate again): does it touch the top pain / block the core loop? Feed winners into new Implementation Plans; file the rest with explicit "Won't (this cycle)."
5. **Ship a new iteration; repeat Protocol B.** Each cycle should feel smaller than the last as you converge. Kill criteria (from Pillar 1 Stage 1) are your license to abandon honestly when the data says so.
6. **The 4-week honesty checkpoint:** if a metric you staked your MVP on hasn't moved, do an outer-loop probe before adding features. Adding features to a product no one wants just makes an unwanted product bigger.

---

## The compounding meta-rule

Every loop you run should make the *next* loop cheaper:
- Each fault found becomes a Forbidden-list entry, a Skill line, a lint rule, or a template field.
- Each successful pattern becomes a Skill example or a scaffold default.
- Each brain file is the accumulated memory that lets a *future* agent start further along.
Do this and your "iteration protocol" stops being a chore and becomes a flywheel: standards encode → agents obey → you review less → you ship faster → you learn faster → standards improve. That compounding is the entire strategic advantage of the agent-first workflow, and it is available only if you keep every lesson written down in the one place the next agent will read.

---
*(Continue to 08 — Templates index + Iteration Log.)*
# APPENDICES — Blank Templates + Iteration Log

In a real project, copy each of these into `/templates` (or `/docs/brain/templates`) and duplicate per use. They are your reusable scaffolding so you never re-derive structure.

---

## Appendix A — IDEA_SHEET.md (Pillar 1, Stage 1)

```md
# Idea Sheet — <NAME>
Date:  Status: [raw | validated | scoped | built | abandoned]

## 1. Napkin sentence
For [who], who [frustration], [product] is a [category] that [core outcome], unlike [alternative] because [differentiator].

## 2. Honesty audit (weakest assumptions)
| Assumption | Checkable cheaply? | How to check | Status |
|---|---|---|---|
| | Y/N | | open/proven/dead |

## 3. Kill criteria (abandon if any, decided BEFORE building)
1. No one in [N] interviews mentions the pain unprompted.
2. [e.g., <5% landing-page signup conversion]
3. [e.g., no one commits to a pilot within X]

## 4. Moat
Declared: [distribution / data / network effects / none-accepted]

## 5. Risk & blocker list
| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
```

## Appendix B — JOURNEY_MAP.md (Pillar 1, Stage 3)

```md
# Journey Map — <segment> → <outcome>
Source: [interview transcripts / session data]. NOT assumptions.

## Current-state path (today, without us)
| # | Step | Emotion | Time | Tool | Friction? |
|---|---|---|---|---|---|
| 1 | ... | frustrated | 10m | spreadsheet | high |

## Future-state path (with us) — steps we DELETE / COMPRESS:
- [delete step 3 & 5 → user goes 6 steps to 3]
- [compress step 2 from 10m to 2m]

## Friction list (ranked by pain×frequency):
1. ...
2. ...

## Happy path + edge paths
- Happy (novice): ...
- Edge: returning power user wants ... ; mistake-recovery path ...
- Psychology hooks to use: [present-bias win, loss-aversion, defaults, status-quo, reciprocity]
```

## Appendix C — MVP_SCOPE.md (Pillar 1, Stage 5)

```md
# MVP Scope — <product>
Core loop (one sentence): [a user arrives → does X → gets Y → returns to Z]
Primary persona:  Primary path (from Journey Map):

## Feature triage
| Must (core) | Should (delight, still core) | Could (defer) | Won't (this version) |
|---|---|---|---|
| 1... | 1... | 1... | 1... |

## Success signals (measure post-launch)
1. Activation: [e.g., 40% of signups complete core action in first session]
2. Usage:      [e.g., median 3 core actions/wk per active user]
3. Retention:  [e.g., week-4 return ≥ X%]

## Manual-behind-the-scenes (do by hand for first N users)
- [onboarding / "AI" features / integrations] → automate only when it hurts.
```

## Appendix D — IMPLEMENTATION_PLAN.md (Pillar 3b) — the delegation contract

```md
# Implementation Plan — <feature>
Status: [draft/ready/delegated/in-review/done]

## Goal (ties to MVP_SCOPE core loop)
## Human context (from JOURNEY_MAP — which user, which pain)
## In scope / OUT of scope
  - In:  ...
  - OUT (explicit, so agent won't add): ...
## Files to create/modify (explicit paths per AGENTS.md)
  - ...
## Tech contract (schema lib, UI primitives, state, tokens — NO new deps w/o approval)
## Data / API contract (request/response types; tables/migrations)
## UX requirements (paste Constraints + Forbidden items; list empty/error/loading)
## Definition of Done (checkable — command+expected, or screenshot)
  - [ ] pnpm lint && typecheck: clean
  - [ ] unit test for core rule: <test> passes
  - [ ] e2e happy path: <spec> passes
  - [ ] screenshots at 375/768/1280 incl. empty+error states (Artifact)
  - [ ] axe: 0 violations; Lighthouse ≥ 90
  - [ ] no new dependencies; no edits to docs/brain/* or applied migrations
## Verification commands the agent must run (exact)
## Sandbox / limits (read-only files; forbidden commands; dev env only; escape hatch)
  - If you must touch a protected file / add a dep / exceed N fix attempts → STOP and ask.
## Success signal to report as Artifact
```

## Appendix E — Interview question bank (Pillar 1, Stage 2 — open with these)

Past-behavior openers (never "would you use X?"):
- "Last time you dealt with [problem], walk me through exactly what you did, step by step."
- "What did you try before that? Why did it not stick?"
- "How often does [situation] come up? What does it cost you (time/money/annoyance)?"
- "What's the most annoying part of [current tool/workaround]?"
- "If you could wave a wand and fix one thing about this, what would it be?"
- "Who else do you know that has this problem? (Can I talk to them?)"  ← sourcing snowball
Probe for: frequency, money, workarounds, emotions. Stop-listening signals: "that's cool, but I wouldn't pay," "I'd use it if it were free," explanations needed twice.

---

# ITERATION LOG — The 60 faults found & fixed in refining this blueprint

**Revision note (v3.0 → v4.0):** this log documents the original three-pass, 60-fault refinement that produced v3.0. After critical user review, v4.0 applied a further structural correction *by running the same protocol*: (1) extended the "stop at ship" scope to a full 7-pillar lifecycle (added Product-Type & Lean-Stack, Launch & Distribution, Monetization & Pricing); (2) fixed the under-use of GitHub by researching, comparing, and mixing multiple open-source repos per workstream into § A; (3) integrated **obra/superpowers** as the recommended build-loop engine (its 7-phase workflow maps onto my build pillars) rather than re-inventing that methodology in-house. The faults below are v1–v3's; v4's own correction pass is summarized above and in § A. This is the protocol working: the document itself keeps getting re-reviewed as the reader finds real gaps.

Executed exactly as instructed: three adversary passes, 20 faults each, each pass rewritten before the next, plus a final consolidation. This proves the protocol was run on this document and models how to run it on yours.

## Pass 1 — faults found (found: 20)
1. Covered the model/agent capabilities at a shallow, generic level — no honest "what it really is / where it bites" mapping for each Google tool.
2. Would have buried "Read this first" operating principles in a long preamble instead of front-loading 5 laws that every pillar obeys.
3. No definition of MVP → the word was used loosely and would have invited scope creep.
4. "Validate before building" had no explicit cost/effort ordering; probes weren't ranked cheap→expensive.
5. Didn't state the interview rule that humans lie to be polite / past-behavior truth vs stated intention — the single most important human-behavior insight, absent.
6. No explicit list of red flags that mean "stop" before scope.
7. User-journey guidance was whiteboard-y (assumed rational users) instead of "code transcripts into steps."
8. Missing concrete psychology hooks (present bias, loss aversion, Hick's law, status quo) to inject real human behavior.
9. Competitor research would have drifted into a bloated, unread market report — no "anti-research rules" or wedge-output framing.
10. UI resources were a vague "use awesome-design-systems" with no primary-system decision rule (control vs. speed) and no "pick ONE foundation" rule.
11. No explicit list of *provenance/curation* law — the exact anti-reinvention strategy the user demanded.
12. Design laws listed aesthetics without *checkable* criteria (contrast ratios, spacing grid) and without pairing with the automated verification (axe/Lighthouse/token lint).
13. No Forbidden list — the "default AI look" anti-patterns the user explicitly feared weren't enumerated.
14. Architecture section risked proposing one rigid framework-specific tree — no "name = documentation / layered deps inward / one source of truth" rule zero.
15. No colocation-vs-promotion rule or barrel discipline — the classic drift source under parallel agents.
16. Engineering laws were vibes (some DRY/quality) without lintable, CI-enforceable form or a shared-schema "API contract first" move.
17. The Antigravity section would have said "structure tasks well" without the *mechanism*: written Implementation Plan files, SKILL.md, mcp_config.json, policy gates — all grounded but missing.
18. No sandboxing/containment doctrine (branch per feature, protected brain files, lean MCP ~25-tool ceiling, no-prod rule, autonomy trust ladder).
19. CI/CD was "push to main and deploy" — no migrations-first/backup/rollback-drill, preview-sweep, or agent-specific guardrails (dep-diff, schema-drift detector, DoD↔CI mapping).
20. The iteration protocol was only an instruction, not a usable runbook — no separation of outer/product vs inner/build loops, no wrong-loop trap, no permanent Protocol A you could actually run.

## Pass 2 — faults found in the rewrite (found: 20, distinct & deeper)
21. Enumerating resources without the licensing caveat risked steering the user into a legal trap.
22. Screenshot/eyeball advice under-specified how an agent verifies "taste" — gave the concrete loop: load page → screenshot happy/empty/error/responsive → diff against constraints.
23. Base/presence in dark-vs-light: "ship light-mode first" was a lazy default; committed to dark+light as first-class and disabled for accent semantics.
24. Font handling overlooked self-hosting/privacy (hotlinking Google Fonts) — gave Fontsource and why.
25. Missed the empty-state/product-copy resource class entirely — one of the highest-leverage free UX wins.
26. MVP auth guidance was naive ("make it login"): scoped to magic-link/OAuth + ONE paid plan and banned orgs/roles/trials-gymnastics at MVP.
27. Didn't codify "manual-behind-the-scenes beats automation for first 20 users" — a huge scope-liberator, added.
28. Definition-of-Done gave vague "ensure it works"; fixed to command+expected-output / screenshot, because unverifiable DoD is the top cause of agent drift.
29. "One agent per feature" stated without the why — clarified branch-per-feature isolates bad bursts and enables cheap rollback.
30. No recovery-point rule (commit known-green before delegating) — added as a safety rail.
31. MCP token/context guidance lacked the "curate to ~15–25, keep well under the practical ceiling" grounding; added stability note.
32. Under-addressed MCP tool-name regex gotcha (dotted tool names fail to load) — added the documented sanitizing-proxy fix.
33. CI "dependency audit" gate and "no silent dep adds by agents" weren't explicit — added.
34. Database conventions lacked owner/tenant scoping at the repository layer (never trust the client) — added as security law.
35. Error handling lumped expected+unexpected together; split into classified `UserFacingError` vs boundary/monitoring capture.
36. Feature-flag usage was vague; pinned to free libs + "ship dark, flip on," and warned against building a flag platform at MVP.
37. No explanation of how standards *compound* (the flywheel that justifies the whole agent-first approach); added the meta-rule.
38. Blamed-agent post-mortem framing absent — added "a botched run is a standards gap, not 'AI is bad,' fix it in the files" so the loop self-improves.
39. Protocol didn't separate Product (outer, weeks, data) vs Build (inner, per-feature) loops — separated them and added the wrong-loop trap.
40. Kill-criteria were implied but not operationalized into the MVP_SCOPE template with abandon-date + the 4-week honesty checkpoint.

## Pass 3 — faults found in the second rewrite (found: 20, cross-cutting & final)
41. No explicit *forward* one-sentence thesis stating what a solo founder actually is in 2026 (a director of agents); added so every later rule hangs on it.
42. Autonomy described only qualitatively; gave the concrete 4-rung trust ladder with the rule "only raise autonomy after standards are encoded & proven."
43. Templates were mentioned but not provided; added four ready-to-copy skeletons (IDEA_SHEET, JOURNEY_MAP, MVP_SCOPE, IMPLEMENTATION_PLAN) + an interview question bank.
44. Data-safety/legal of collected user research wasn't noted; added minimal "no PII/logging secrets, comply with data regs" pointer.
45. Barrier to measuring retention unstated; named free PostHog/Plausible and warned ~5-metric cap (anti-dashboard-bloat law).
46. Onboarding UX gave "one step" without the "3–4 new concepts cap + progressive disclosure" cognitive-load justification.
47. Marketing/landing vs. product-app design split wasn't explicit in the laws; clarified density/spacing differs by screen type.
48. Empty/error/loading/partial/offline "every state designed" law was mentioned but not enforced as a DoD item; added to the plan template.
49. Global consistency of the *pipeline diagram* and section numbering across a 4-part doc wasn't maintained; added explicit "(Continue →)" pointers per part so the assembled file is coherent.
50. Accessibility was occasionally reduced to contrast; reinforced keyboard traps, focus-visible, prefers-reduced-motion as explicit laws.
51. No warning against the "reporting tool nobody asked for" dashboard instinct — added the "boring core" + "no charts you didn't earn" test.
52. Some names/files referenced but undefined; added the table "where things go" and a "where X lives" decision table so a stranger/agent never guesses.
53. Interview guidance lacked a sourcing/snowball step to find more users; added "who else has this problem?" prompt.
54. Did not explain *why* markdown files (agents read files better than chat) — made the "artifact is the interface" law explicit up top.
55. No instruction to keep brain files from being restated in plans (link, don't restate) — the #1 source of constraint drift.
56. Error-monitoring was optional-sounding; elevated Sentry (free tier) to "the MVP must-have" in post-deploy verification.
57. No explicit "rehearse the rollback" drill; added it so confident shipping is backed by a proven escape hatch.
58. The value of batching multiple independent features across parallel agents (Manager view) vs. serializing shared-file edits wasn't clear; added the guidance and its conflict caveat.
59. Long-list-of-sources risked overwhelm; structured it into lettered sub-groups (foundations, indexes, color, type, icons, illustration, copy) each with a purpose.
60. No explicit *goal line* for the relentless protocol (stop when adversary pass yields only nits + remaining risk is testable & queued), so it could never "finish" — defined the stopping rule that prevents infinite thrash.

## Final consolidation (Pass 3 fixes applied + 3-commitment close-out)
- Rewrote once after each pass; Pass 3 output is this document, re-read and re-linked for coherence (see the "(Continue)" arrows).
- Stopping condition met: a further adversary pass surfaced only cosmetic nits (wording/ordering) and one queued empirical check ("re-verify live Antigravity paths in current docs before building habits") — recorded in §1.
- The protocol is not complete-in-itself: it converges to *well-scrutinized*, hands the final verdict to real users in the outer loop, and requires you to keep running Protocol A forever (not once).

**What 60 faults taught (the takeaway for your product):** the biggest risks were never technical — they were (a) skipping real humans, (b) unverifiable instructions the machine would fill with generic defaults, and (c) uncontained autonomy. Every fix moved the template toward *constraint-binding + verification + containment*. Those three are the entire game. Run them on your idea and your agents will build something worth keeping.
